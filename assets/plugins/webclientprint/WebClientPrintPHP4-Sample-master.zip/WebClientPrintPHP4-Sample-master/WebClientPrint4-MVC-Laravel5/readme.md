# WebClientPrint 4.0 for PHP - Laravel 5 Sample

## IMPORTANT NOTE
This folder **DOES NOT CONTAIN THE WHOLE FILES** which are part of a Laravel 5 project BUT the files you have to **edit or add** to your local test project!
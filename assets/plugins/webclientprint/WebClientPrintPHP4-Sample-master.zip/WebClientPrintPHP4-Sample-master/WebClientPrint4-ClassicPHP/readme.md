# WebClientPrint 4.0 for Classic PHP

## IMPORTANT NOTE
WebClientPrint 4.0 requires PHP 5.3 or greater!